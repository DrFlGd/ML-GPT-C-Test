Model Library

This folder is a library for the Model Library desktop app. Your models are in
the folders beside this one, one folder per model, laid out by your schemas
(for example Wargames/Warhammer 40k/Tyranid/Hive Tyrant (Author)/). Each model
folder has a model.json with its details, so the library can be moved, copied
or synced, and opened again by any version of the app.

_library/library.json   name, favourites and library-wide settings
_library/schemas/       your categories: their subcategory folders and fields
Unsorted/               imported models that have no schema yet

The app's search index and caches are kept on each computer, not here.
